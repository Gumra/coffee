
-- --------------------------------------------------------

--
-- Структура таблицы `history`
--

CREATE TABLE `history` (
  `id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `user` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `number` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` int(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `history`
--

INSERT INTO `history` (`id`, `date`, `user`, `number`, `total`) VALUES
(12, '2021-01-09', 'Человек', 'esx52cmaqt', 102),
(13, '2021-01-09', 'Дмитрий', '2wvtzlbcy7', 170),
(14, '2021-01-10', 'Дмитрий', 'lv70xmp19z', 102),
(15, '2021-01-16', 'Дмитрий', '0ex4z9bsp6', 374),
(16, '2021-01-21', 'Дмитрий', 'okj51yf98r', 102),
(17, '2021-01-21', 'Дмитрий', 'o0nsti67xg', 102),
(18, '2021-01-25', 'Дмитрий', '41yamfpdc5', 51);
