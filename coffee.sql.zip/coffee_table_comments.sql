
-- --------------------------------------------------------

--
-- Структура таблицы `comments`
--

CREATE TABLE `comments` (
  `id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `comment` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `comments`
--

INSERT INTO `comments` (`id`, `date`, `user`, `comment`) VALUES
(1, '2021-01-07', 'Человек', 'ккп'),
(2, '2021-01-07', 'Человек', 'Привет, Вика'),
(3, '2021-02-05', 'Женя', 'оо'),
(4, '2021-02-06', 'Женя', 'ккккк <script>alert(\"ddd\")</script>'),
(5, '2021-02-06', 'Женя', 'отзыв <script>alert(\"DDD\")</script>'),
(6, '2021-02-06', 'Женя', 'отзыв <script>alert(\"DDD\")</script>');
