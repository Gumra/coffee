
-- --------------------------------------------------------

--
-- Структура таблицы `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `user` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL,
  `names` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `prices` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `stocks` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total` int(100) DEFAULT NULL,
  `total_lol` int(100) DEFAULT NULL,
  `number` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(1) DEFAULT NULL,
  `status_admin` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `orders`
--

INSERT INTO `orders` (`id`, `user`, `date`, `names`, `prices`, `stocks`, `total`, `total_lol`, `number`, `status`, `status_admin`) VALUES
(35, 'Дмитрий', '2021-01-25', 'Медовик-шоколадный;', '120;', '1;', 51, NULL, '41yamfpdc5', 1, 0),
(36, 'Женя', '2021-02-05', 'Медовик-шоколадный;', '120;', '1;', 51, NULL, 'r2azylc1ie', 0, 0);
