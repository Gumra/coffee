
-- --------------------------------------------------------

--
-- Структура таблицы `faq`
--

CREATE TABLE `faq` (
  `id` int(11) NOT NULL,
  `date` date DEFAULT NULL,
  `user` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `question` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `answer` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `faq`
--

INSERT INTO `faq` (`id`, `date`, `user`, `question`, `answer`) VALUES
(2, '2021-01-05', 'Неизвестный', 'Какой сорт кофе популярный?', 'Paulig'),
(16, '2021-02-07', 'Неизвестный', 'ss&lt;script&gt;alert(&quot;a&quot;)&lt;/script&gt;', NULL);
